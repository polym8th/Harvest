// jshint esversion: 8
/* global bootstrap */

document.addEventListener("DOMContentLoaded", function() {
    var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
    messageModal.show();
});